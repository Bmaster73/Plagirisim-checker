# plagiarism_checker

Online free tool to check the plagiarism for the uploaded document.
